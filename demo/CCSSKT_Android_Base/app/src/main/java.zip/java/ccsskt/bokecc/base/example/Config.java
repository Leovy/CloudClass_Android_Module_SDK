package ccsskt.bokecc.base.example;

/**
 * 作者 ${CC视频}.<br/>
 */

public class Config {
    public static final String APP_VERSION = "1.1.1";
    public static final String FORCE_KILL_ACTION = "force_kill_action";
    public static final String FORCE_KILL_VALUE = "force_kill";
    public static final long SPLASH_DELAY = 2 * 1000L;

    public static String mRoomId, mUserAccount, mRole,ServerUrl;

}
